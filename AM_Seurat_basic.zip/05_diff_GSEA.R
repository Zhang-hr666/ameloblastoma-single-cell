################################################
### 作者：果子
### 更新时间：2022-12-30
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
library(Seurat)
### 读入数据
scobj <- readRDS(file = "output/hamony_seurat_annotaion.rds")
DimPlot(scobj, label = TRUE)
DimPlot(scobj, label = TRUE,split.by = "group")
########################################################
### 基于群marker的富集分析策略
### https://mp.weixin.qq.com/s/nvOXM2hpZq3UI_Npjhk8HQ
### 神奇操作, 制作新的分组
scobj$celltype.stim <- paste(scobj$celltype, scobj$group, sep = "_")
metadata <- scobj@meta.data
Idents(scobj) <- "celltype.stim"
table(scobj$celltype.stim)

### 找差异，每个亚群的marker
sce.markers <- FindAllMarkers(object = scobj, 
                              only.pos = TRUE, 
                              min.pct = 0.25,
                              thresh.use = 0.25)

saveRDS(sce.markers,file = "output/Seurat_sce_split_markers.rds")
sce.markers <- readRDS(file = "output/Seurat_sce_split_markers.rds")
library(dplyr)
markers <- sce.markers %>%
  filter(p_val_adj < 0.001) 

#devtools::install_github("YuLab-SMU/clusterProfiler")
#BiocManager::install("org.Hs.eg.db")
library(clusterProfiler)
### 名称转换
gid <- bitr(unique(markers$gene), 'SYMBOL', 'ENTREZID', OrgDb= 'org.Hs.eg.db')
### 交叉合并
colnames(gid)[1] <- "gene"
markers <- merge(markers, gid, by='gene')
### 数据预处理
### https://mp.weixin.qq.com/s/4cV8R4NxNklW4jIzsqLGbg
library(tidyr)
markers <- markers  %>%
  separate(cluster,into = c("celltype","group"),sep = "_",remove = F)%>%
  filter(!celltype %in% c("Eryth","Mk","Mono/Mk Doublets"))

### 多组富集分析
x = compareCluster(ENTREZID ~ celltype+group, data = markers, fun='enrichKEGG')

### 绘图
library(ggplot2)
dotplot(x, label_format=60,x="group") + 
  facet_grid(~celltype)+
  theme(axis.text.x = element_text(angle=45, hjust=1)) 
### 换风格
dotplot(x, label_format=60,x="celltype") + 
  facet_grid(~group)+
  theme(axis.text.x = element_text(angle=45, hjust=1)) 

##################################################
### 基于差异分析的GSEA分析策略(对接GZ00技能)
### 同一群细胞中, 处理和对照的差异
interferon.response <- FindMarkers(scobj, 
                                   ident.1 = "CD14 Mono_STIM",
                                   ident.2 = "CD14 Mono_CTRL", 
                                   logfc.threshold = 0)
head(interferon.response, n = 15)

### GSEA 分析
## geneList 三部曲
gene_df <- interferon.response
## 1.获取基因logFC
geneList <- gene_df$avg_log2FC
## 2.命名
names(geneList) =  rownames(gene_df)
## 3.排序很重要
geneList = sort(geneList, decreasing = TRUE)

head(geneList)

library(clusterProfiler)
#################################################################
### 1.kegg 通路
## 读入kegg gene set
genesets  <- read.gmt("resource/c2.cp.kegg.v2022.1.Hs.symbols.gmt")
y <- GSEA(geneList,TERM2GENE = genesets)
yd <- as.data.frame(y)
### 看整体分布
dotplot(y,showCategory=12,split=".sign")+facet_grid(~.sign)
library(enrichplot)
gseaplot2(y,"KEGG_RIBOSOME",color = "red",pvalue_table = T)
gseaplot2(y,"KEGG_RIG_I_LIKE_RECEPTOR_SIGNALING_PATHWAY",color = "red",pvalue_table = T)

#################################################################
### 2.hallmarks gene set
genesets <- read.gmt("resource/h.all.v2022.1.Hs.symbols.gmt")
### 主程序GSEA
y <- GSEA(geneList,TERM2GENE = genesets)
yd <- as.data.frame(y)
library(ggplot2)
dotplot(y,showCategory=30,split=".sign")+facet_grid(~.sign)
library(enrichplot)
gseaplot2(y, "HALLMARK_INTERFERON_ALPHA_RESPONSE",color = "red",pvalue_table = T)

#################################################################
### 3.转录因子
## 读入转录因子,高能，需要专业知识消化
genesets <- read.gmt("resource/ENCODE_TF_ChIP-seq_2015.txt")
y <- GSEA(geneList,TERM2GENE = genesets)
yd <- as.data.frame(y)
### 看整体分布
dotplot(y,showCategory=30,split=".sign")+facet_grid(~.sign)

gseaplot2(y,"STAT2 K562 hg19",color = "red",pvalue_table = T)

#################################################################
### 4.免疫相关基因集
## 专业背景很重要！
genesets <- read.gmt("resource/c7.all.v2022.1.Hs.symbols.gmt")
y <- GSEA(geneList,TERM2GENE = genesets)
yd <- as.data.frame(y)
### 看整体分布
dotplot(y,showCategory=5,split=".sign",label_format = 60)+facet_grid(~.sign)

gseaplot2(y,"HARALAMBIEVA_PBMC_M_M_R_II_AGE_11_22YO_VACCINATED_VS_UNVACCINATED_7YR_UP",color = "red",pvalue_table = T)

### 这些gene set从哪来的
### 1.board 官网
### 2.https://amp.pharm.mssm.edu/Enrichr/#stats
### 该部分所有数据集已经下载，在附赠教程中
### 3.自己自作或者收集

### 有个问题
### 哪种细胞受扰动影响最大？-> GRN 课程学起来！

#################################################################
## GZ06_必备技能GSEA，富集分析的神器，量化一切通路。 (课程赠送) 
## https://weidian.com/item.html?itemID=3749911422
## 原理文字版
## https://mp.weixin.qq.com/s/FyXMarhQY6r-oymTd491Sw
## 还可以选择火山图来呈现
## https://mp.weixin.qq.com/s/jolWmKoLic5m_M5F1E8K2g
## 其他物种的GSEA，比如老鼠该怎么做呢
### 使用msigdbr包
### https://cran.r-project.org/web/packages/msigdbr/vignettes/msigdbr-intro.html


### 关于comparecluster,可以阅读材料是
### 用clusterProfiler一行代码对单细胞的marker genes做功能富集分析
### https://mp.weixin.qq.com/s/nvOXM2hpZq3UI_Npjhk8HQ
### 把compareCluster富集后缺失的组显示出来
### https://mp.weixin.qq.com/s/dHQtS18FsyRT-0XSieCXWQ
### 做通路富集分析的时候究竟输入多少个基因？
### https://mp.weixin.qq.com/s/4cV8R4NxNklW4jIzsqLGbg