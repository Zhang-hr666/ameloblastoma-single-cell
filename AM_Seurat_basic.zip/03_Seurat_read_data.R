################################################
### 作者：果子
### 更新时间：2022-12-31
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
library(Seurat)

###########################################################################
### 案例1
### Read10X读入数据
scdata <- Read10X(data.dir = "data/10x/filtered_gene_bc_matrices/hg19/")

### 分步读入数据
library(Matrix)
count_matrix <- Matrix::readMM("data/10x/filtered_gene_bc_matrices/hg19/matrix.mtx")
gene_id <- read.table("data/10x/filtered_gene_bc_matrices/hg19/genes.tsv")
barcode <- read.table("data/10x/filtered_gene_bc_matrices/hg19/barcodes.tsv")
rownames(count_matrix) <- gene_id$V2
colnames(count_matrix) <- barcode$V1

#################################################################################
### 读入GEO下载的数据
rm(list = ls())
### 案例2: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE188987
### 1.分步读入
count_matrix <- Matrix::readMM("data/GSE188987/GSE188987_YJ_Lib9_1_matrix.mtx.gz")
gene_id <- read.table("data/GSE188987/GSE188987_YJ_Lib9_1_features.tsv.gz")
barcode <- read.table("data/GSE188987/GSE188987_YJ_Lib9_1_barcodes.tsv.gz")
rownames(count_matrix) <- gene_id$V2
colnames(count_matrix) <- barcode$V1

### 2.修改后Read10X读入
### 模仿之前的读法
scdata1 <- Read10X(data.dir = "data/GSE188987_2/")
### 不解压读取
scdata2 <- Read10X(data.dir = "data/GSE188987_3/")

###############################################################################
rm(list = ls())
# 案例3: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE157783
# 读取UMI的矩阵
umi_count <- data.table::fread('data/GSE157783/IPDCO_hg_midbrain_UMI.tsv',data.table = F)
test <- umi_count[1:10,1:10]
# 读取基因
gene_id <- read.table("data/GSE157783/IPDCO_hg_midbrain_genes.tsv", header = TRUE, sep = "\t")
# 读取barcode
barcode <- read.table("data/GSE157783/IPDCO_hg_midbrain_cell.tsv", header = TRUE, sep = "\t")

# 将UMI的数据框转成矩阵
umi_count <- as.matrix(umi_count)
# 为矩阵添加行名，也就是基因名, umi_count，就是用于后续分析的表达量矩阵
rownames(umi_count) <- gene_id$gene


