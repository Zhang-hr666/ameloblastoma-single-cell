library(scGate) # install.packages("scGate") for R 4.2
# devtools::install_github("carmonalab/scGate", ref="v1.2.0") for R < 4.2
library(Seurat)
library(patchwork)
setwd(here::here())
dir.create("output/scGate")

# Ref: https://satijalab.org/seurat/articles/integration_introduction.html
#### scGate ####
seu <- readRDS("data/hamony_seurat_annotaion.rds")
p1 <- DimPlot(seu, label = T, group.by = "celltype") + NoLegend()
p1

## NK cell
VlnPlot(seu, features = c("KLRD1", "GNLY", "CD3D"), group.by = "celltype", stack = T)
FeaturePlot(seu, features = c("KLRD1", "GNLY", "CD3D", "CD8A"))

NK_model.1 <- gating_model(name = "NK1", signature = c("KLRD1", "GNLY"))
NK_model.2 <- gating_model(name = "NK2", signature = c("KLRD1", "CD3D-"))
NK_model.3 <- gating_model(name = "NK3", signature = c("KLRD1", "GNLY", "CD3D-"))
NK_model.4 <- gating_model(name = "NK4", signature = c("KLRD1", "GNLY", "CD3D-", "CD8A-"))

seu <- scGate(data = seu, model = NK_model.1, ncores = 5, k.param = 20, output.col.name = "NK1")
seu <- scGate(data = seu, model = NK_model.2, ncores = 5, k.param = 20, output.col.name = "NK2")
seu <- scGate(data = seu, model = NK_model.3, ncores = 5, k.param = 20, output.col.name = "NK3")
seu <- scGate(data = seu, model = NK_model.4, ncores = 5, k.param = 20, output.col.name = "NK4")

p2 <- DimPlot(seu, group.by = "NK1")
p3 <- DimPlot(seu, group.by = "NK2")
p4 <- DimPlot(seu, group.by = "NK3")
p5 <- DimPlot(seu, group.by = "NK4")

p1 + ggsci::scale_color_d3("category20")
(p2 + p3) / (p4 + p5)

VlnPlot(seu, group.by = "celltype",
        features = paste0(paste0("NK", 1:4), "_UCell"),
        stack = T)
FeaturePlot(seu, features = paste0(paste0("NK", 1:4), "_UCell"))
table(seu$celltype, seu$NK1)
table(seu$celltype, seu$NK2)
table(seu$celltype, seu$NK3)
table(seu$celltype, seu$NK4)

## Monocyte
seu$is.mono <- ifelse(seu$celltype %in% c("CD14 Mono", "CD16 Mono", "Mono/Mk Doublets"), "Mono", "Others")
seu$is.mono[seu$celltype == "DC"] <- "DC"

Idents(seu) <- seu$is.mono
seu.ds <- subset(seu, downsample = 1000)
mono.markers <- FindAllMarkers(seu.ds, only.pos = F)
mono.markers <- FindMarkers(seu.ds, ident.1 = "Mono", ident.2 = "DC")

source("R/RM_utils.R")
mono.markers <- mcFindAllMarkers(seu.ds, only.pos = F, n.cores = 3)

VlnPlot(seu, features = c("CCL7","CCL2","CCR7","HLA-DQA1"), group.by = "celltype", stack = T)
VlnPlot(seu, features = c("CCL2","CD14","FCGR3A","CD86"), group.by = "celltype", stack = T)

FeaturePlot(seu, features = "HLA-DQA1")

# Mono_model <- gating_model(name = "Monocyte", signature = c("CCL2","CD14","FCGR3A","CD86","HLA-DQA1-"))
Mono_model <- gating_model(name = "Monocyte", signature = c("CD86","S100A11","CD14","CD3D-","GPR183-"))

seu <- scGate(data = seu, model = Mono_model, ncores = 5, k.param = 20,
              output.col.name = "Mono")

p2 <- DimPlot(seu, group.by = "Mono")
p1 + p2

saveRDS(Mono_model, "output/scGate/Mono_model.rds")

