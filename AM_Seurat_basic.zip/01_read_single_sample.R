################################################
### 作者：果子
### 更新时间：2023-01-01
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com


library(Seurat)
## 加载数据
## https://satijalab.org/seurat/archive/v3.0/immune_alignment.html
## https://www.dropbox.com/s/79q6dttg8yl20zg/immune_alignment_expression_matrices.zip?dl=1

###########################################################
### 处理第1个样本
### 读入数据
rm(list = ls())
scdata <- data.table::fread('data/immune_stimulated_expression_matrix.txt.gz',data.table = F)
test <- scdata[1:10,1:10]
### 第一列变成行名
rownames(scdata) <- scdata[,1]
scdata <- scdata[,-1]
test <- scdata[1:10,1:10]
### 创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                            project = "pbmc_stim", 
                            min.cells = 3, 
                            min.features = 200)
### metadata 增加分组信息
metadata = scobj@meta.data
scobj@meta.data$group = "STIM"
saveRDS(scobj,file = "output/stim_seurat.rds")

###########################################################
### 处理第2个样本
### 读入数据
rm(list = ls())
scdata <- data.table::fread('data/immune_control_expression_matrix.txt.gz',data.table = F)
test <- scdata[1:10,1:10]
### 第一列变成行名
rownames(scdata) <- scdata[,1]
scdata <- scdata[,-1]
test <- scdata[1:10,1:10]
### 创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                            project = "pbmc_ctrl", 
                            min.cells = 3, 
                            min.features = 200)
### metadata 增加分组信息
metadata = scobj@meta.data
scobj@meta.data$group = "CTRL"
saveRDS(scobj,file = "output/ctrl_seurat.rds")

######################################################################
### 也可以在GEO下载数据后自己调整
### https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE96583

### 分步读取
rm(list = ls())
library(Matrix)
scdata <- Matrix::readMM("data/GSE96583/GSM2560248_2.1.mtx.gz")
gene_id <- read.table("data/GSE96583/GSE96583_batch2.genes.tsv.gz")
barcode <- read.table("data/GSE96583/GSM2560248_barcodes.tsv.gz")
rownames(scdata) <- gene_id$V2
colnames(scdata) <- barcode$V1

### 读取另外一个数据
rm(list = ls())
scdata <- Matrix::readMM("data/GSE96583/GSM2560249_2.2.mtx.gz")
gene_id <- read.table("data/GSE96583/GSE96583_batch2.genes.tsv.gz")
barcode <- read.table("data/GSE96583/GSM2560249_barcodes.tsv.gz")
rownames(scdata) <- gene_id$V2
colnames(scdata) <- barcode$V1

### 如果需要Read10X 就需要三个文件,
### 可以自己改造一下,barcodes.tsv.gz, features.tsv.gz,matrix.mtx.gz
rm(list = ls())
scdata <- Read10X(data.dir = "data/GSE96583/stim/")
### 创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                            project = "pbmc_stim", 
                            min.cells = 3, 
                            min.features = 200)
### metadata 增加分组信息
metadata = scobj@meta.data
scobj@meta.data$group = "STIM"
#saveRDS(scobj,file = "output/stim_seurat.rds")

rm(list = ls())
scdata <- Read10X(data.dir = "data/GSE96583/ctrl/")
### 创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                            project = "pbmc_ctrl", 
                            min.cells = 3, 
                            min.features = 200)
### metadata 增加分组信息
metadata = scobj@meta.data
scobj@meta.data$group = "CTRL"
#saveRDS(scobj,file = "output/ctrl_seurat.rds")


rm(list = ls())
scdata <- Read10X(data.dir = "data/FZCscRNAseq/")
### 创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                            project = "am1", 
                            min.cells = 3, 
                            min.features = 200)
### metadata 增加分组信息
metadata = scobj@meta.data
scobj@meta.data$group = "AM"
saveRDS(scobj,file = "output/AM1_seurat.rds")

