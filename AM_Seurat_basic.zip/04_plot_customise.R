################################################
### 作者：果子
### 更新时间：2023-06-03
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
### 可供探索的链接
### https://enblacar.github.io/SCpubr-book/index.html
### https://samuel-marsh.github.io/scCustomize/
### https://github.com/junjunlab/scRNAtoolVis
### https://github.com/zhanghao-njmu/SCP
# options(timeout=9999999)
# remotes:::install_github('junjunlab/scRNAtoolVis')
##tidyverse
## geomtextpath,ggdendro,ggh4x,ggunchull,jjAnno


if (!requireNamespace("ggunchull", quietly = TRUE)) {
  install.packages("./resource/ggunchull-main/", type = "source", repos = NULL)
}

if (!requireNamespace("jjAnno", quietly = TRUE)) {
  install.packages("./resource/jjAnno-master/", type = "source", repos = NULL)
}

if (!requireNamespace("scRNAtoolVis", quietly = TRUE)) {
  install.packages("./resource/scRNAtoolVis-master/", type = "source", repos = NULL)
}

library(scRNAtoolVis)
httest <- system.file("extdata", "htdata.RDS", package = "scRNAtoolVis")
pbmc <- readRDS(httest)

# load markergene
markergene <- system.file("extdata", "top5pbmc.markers.csv", package = "scRNAtoolVis")
markers <- read.table(markergene, sep = ',', header = TRUE)
AverageHeatmap(object = pbmc,
               markerGene = markers$gene)

## myown data
rm(list = ls())

scobj <- readRDS(file = "output/Seurat_single_sample_scobj.rds")
all_markers <- readRDS(file = "output/Seurat_single_sample_all_markers.rds")
library(dplyr)
top5_markers <- all_markers %>%
  group_by(cluster) %>%
  arrange(desc(avg_log2FC))%>%
  slice(1:5) %>%
  ungroup() %>%
  pull(gene) %>%
  unique()

AverageHeatmap(object = scobj,
               markerGene = top5_markers)

### volcano plot
# plot
test <- system.file("extdata", "pbmc.markers.csv", package = "scRNAtoolVis") 
markers <- read.csv(test)

markerVocalno(markers = markers,
              topn = 5,
              labelCol = ggsci::pal_npg()(9))

## my own data
markerVocalno(markers = all_markers,
              topn = 5,
              labelCol = ggsci::pal_npg()(9))

##############################################################
### 画图和配色
### 细胞类群作图如何改颜色？
rm(list = ls())
scobj = readRDS(file = "output/Seurat_single_sample_scobj.rds")

DimPlot(scobj,label = T)
metadata = scobj@meta.data
design=model.matrix(~0+ metadata$celltype)
design <- as.data.frame(design)
colnames(design)=levels(metadata$celltype)

scobj@meta.data <- cbind(scobj@meta.data,design)
FeaturePlot(scobj,features = levels(metadata$celltype))

### 上色
color_use <- DiscretePalette_scCustomize(num_colors = 9, palette = "varibow")

DimPlot(scobj,label = T,cols = color_use)
FeaturePlot(scobj,features = "Naive CD4+ T",cols = c("lightgrey", "#FF7373"))

### 批量操作
plotlist = list()
features = levels(metadata$celltype)
for (i in 1:9) {
  print(i)
  plotlist[[features[i]]] = FeaturePlot(scobj,features = features[i],cols = c("lightgrey", color_use[i])) +NoLegend()
}

library(patchwork)
wrap_plots(plotlist)

### https://samuel-marsh.github.io/scCustomize/articles/Color_Palettes.html