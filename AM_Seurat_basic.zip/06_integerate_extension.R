################################################
### 作者：果子
### 更新时间：2023-01-01
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
library(Seurat)
library(harmony)
library(SeuratWrappers)
################################################
### 1.读入数据，有多少个就读入多少
data1 <- readRDS(file = "output/stim_seurat.rds")
data2 <- readRDS(file = "output/ctrl_seurat.rds")
### 把数据变成list
data <- list(data1,data2)
################################################
### 2.Merge 合并数据
scobj <- merge(x=data[[1]], y = data[-1])
## 删除所有data前缀的数据,释放空间
rm(list = ls(pattern="data.*"))

################################################
### 使用Harmony去除批次
scobj <- NormalizeData(scobj)
scobj <- FindVariableFeatures(scobj, selection.method = "vst", nfeatures = 2000)
scobj <- ScaleData(scobj, features = rownames(scobj))
scobj <- RunPCA(scobj, features = VariableFeatures(object = scobj),reduction.name = "pca")
### 不进行批次矫正
scobj <- RunUMAP(scobj,reduction = "pca", dims = 1:10, reduction.name = "umap_naive")
### 使用harmony进行批次矫正
### 默认reduction = "pca",group.by.vars参数输入的是批次信息,reduction.save 是结果保存的名称
scobj <- RunHarmony(scobj,reduction = "pca",group.by.vars = "group",reduction.save = "harmony")
scobj <- RunUMAP(scobj, reduction = "harmony", dims = 1:30,reduction.name = "umap")

p1 <- DimPlot(scobj, reduction = "umap_naive",group.by = "group")
p2 <- DimPlot(scobj, reduction = "umap",group.by = "group")
p1+p2

scobj <- FindNeighbors(scobj, reduction = "harmony", dims = 1:30)
### 设置多个resolution选择合适的resolution
scobj <- FindClusters(scobj, resolution = 0.5)

#################################################
### 使用Seurat
### https://satijalab.org/seurat/articles/integration_introduction.html
# split the dataset into a list of two seurat objects (stim and CTRL)
scobj <- SplitObject(scobj, split.by = "group")
# normalize and identify variable features for each dataset independently
scobj <- lapply(X = scobj, FUN = function(x) {
  x <- NormalizeData(x)
  x <- FindVariableFeatures(x, selection.method = "vst", nfeatures = 2000)
})
# select features that are repeatedly variable across datasets for integration
features <- SelectIntegrationFeatures(object.list = scobj)
### 该步骤十分慢
immune.anchors <- FindIntegrationAnchors(object.list = scobj, anchor.features = features)
saveRDS(immune.anchors,file = "output/immune.anchors.rds")
immune.anchors <- readRDS(file = "output/immune.anchors.rds")
scobj <- IntegrateData(anchorset = immune.anchors)
# specify that we will perform downstream analysis on the corrected data note that the
# original unmodified data still resides in the 'RNA' assay
DefaultAssay(scobj) <- "integrated"

# Run the standard workflow for visualization and clustering
scobj <- ScaleData(scobj, verbose = FALSE)
scobj <- RunPCA(scobj, npcs = 30, verbose = FALSE)
scobj <- RunUMAP(scobj, reduction = "pca", dims = 1:30)
scobj <- FindNeighbors(scobj, reduction = "pca", dims = 1:30)
scobj <- FindClusters(scobj, resolution = 0.5)
DimPlot(scobj, reduction = "umap",group.by = "group")

################################################
rm(list=ls())

### 使用 fastMNN 去除批次
### 1.读入数据，有多少个就读入多少
data1 <- readRDS(file = "output/stim_seurat.rds")
data2 <- readRDS(file = "output/ctrl_seurat.rds")
### 把数据变成list
data <- list(data1,data2)
### 2.Merge 合并数据
scobj <- merge(x=data[[1]], y = data[-1])
scobj <- NormalizeData(scobj)
scobj <- FindVariableFeatures(scobj)
scobj <- RunFastMNN(object.list = SplitObject(scobj, split.by = "group"))
scobj <- RunUMAP(scobj, reduction = "mnn", dims = 1:30)
scobj <- FindNeighbors(scobj, reduction = "mnn", dims = 1:30)
scobj <- FindClusters(scobj)
DimPlot(scobj, reduction = "umap",group.by = "group")

################################################
### 使用 Liger(速度太慢)
scobj <- NormalizeData(scobj)
scobj <- FindVariableFeatures(scobj)
scobj <- ScaleData(scobj, split.by = "group", do.center = FALSE)
scobj <- RunOptimizeALS(scobj, k = 20, lambda = 5, split.by = "group")
scobj <- RunQuantileNorm(scobj, split.by = "group")
scobj <- RunUMAP(scobj, dims = 1:ncol(scobj[["iNMF"]]), reduction = "iNMF")

scobj <- FindNeighbors(scobj, reduction = "iNMF", dims = 1:20)
scobj <- FindClusters(scobj, resolution = 0.55)
DimPlot(scobj, reduction = "umap",group.by = "group")

### 推荐阅读
### http://htmlpreview.github.io/?https://github.com/satijalab/seurat-wrappers/blob/master/docs/fast_mnn.html
### http://htmlpreview.github.io/?https://github.com/satijalab/seurat-wrappers/blob/master/docs/liger.html
### https://theislab.github.io/scib-reproducibility/


