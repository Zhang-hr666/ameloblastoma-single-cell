################################################
### 作者：果子
### 更新时间：2023-06-04
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
library(Seurat)
scobj <- readRDS(file = "output/hamony_seurat_unannotaion_subset2500.rds")

scobj@meta.data$seurat_clusters <- scobj@meta.data$RNA_snn_res.0.5
Idents(scobj) <- "seurat_clusters"
DimPlot(scobj, reduction = "umap", label = T)
### 先分大群, 如何知道群? marker哪里来
### http://bio-bigdata.hrbmu.edu.cn/CellMarker/
### B: "MS4A1", "CD79A"
### NK: "GNLY", "NKG7"
### T: "CD3E","CD8A","CD4","IL7R", 
### Monocyte: "CD14", "FCGR3A", "LYZ"
### DC "FCER1A"
### Megakaryocytes/Platelet: "PPBP"
### Erythrocytes: "HBB","HBA2"

marker_genes <- c("MS4A1", "CD79A","CD19")
marker_genes <- c("GNLY", "NKG7")
marker_genes <- c("CD3E","CD8A","CD4","IL7R")
marker_genes <- c("CD14", "FCGR3A", "LYZ")
marker_genes <- c("FCER1A", "PPBP")
marker_genes <- c("HBB","HBA2")

### 使用VlnPlot画marker小提琴图
VlnPlot(scobj, features = marker_genes)
### 使用FeaturePlot画出特征分布图
FeaturePlot(scobj, features = marker_genes, order = TRUE,ncol=2)

library(Nebulosa)
plot_density(scobj, features= c("CD8A", "CCR7"),joint = TRUE)+
  plot_layout(nrow = 1)

plot_density(scobj, features= c("CD4", "CCR7"),joint = TRUE)+
  plot_layout(nrow = 1)

plot_density(scobj, features= c("CD4", "CREM"),joint = TRUE)+
  plot_layout(nrow = 1)

plot_density(scobj, features= c("CD69", "CREM"),joint = TRUE)+
  plot_layout(nrow = 1)

### 再确定细节
## DC https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5775029/
## http://117.50.127.228/CellMarkerSearch.jsp
## cDC
marker_genes <- c("CLEC9A","ITGAM","ITGAE","FCER1A")
## pDC
marker_genes <- c("IL3RA","HLA-DRA")
VlnPlot(scobj, features = marker_genes)

plot_density(scobj, features= c("CLEC9A","ITGAM"),joint = TRUE)+
  plot_layout(nrow = 1)

## T细胞以及B细胞激活
## https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4110661/
marker_genes <- c("CCR7","SELL","CREM","CD69")
VlnPlot(scobj, features = marker_genes)
FeaturePlot(scobj, features = marker_genes, order = TRUE,ncol=3)

################################################
### 找出所有的marker
all_markers <- FindAllMarkers(object = scobj)
saveRDS(all_markers,file = "output/Seurat_stim_all_markers.rds")
library(dplyr)
top_markers <- all_markers %>%
  group_by(cluster) %>%
  arrange(desc(avg_log2FC))%>%
  slice(1:15) %>%
  ungroup() 

### 不好确定的时候,换一种作图方式
library(Nebulosa)
marker_genes <- c("CCR7","SELL","CREM","CD69")
plot_density(scobj,features = marker_genes) + plot_layout(ncol = 2)

################################################
### 确定注释结果三部曲
### A.确认群的个数
head(Idents(scobj))
Idents(scobj) <- "seurat_clusters"
DimPlot(scobj, reduction = "umap", label = T)
### B.给每个群添加注释
scobj <- RenameIdents(scobj,
                      "0"="CD14 Mono",
                      "1"="CD4 Naive T", 
                      "2"="CD4 Memory T", 
                      "3"= "CD8 T", 
                      "4"= "B cell", 
                      "5"= "NK",
                      "6"= "CD8 Naive T", 
                      "7"= "CD16 Mono", 
                      "8"= "T Activated",
                      "9"= "Mk", 
                      "10"= "cDC", 
                      "11"= "B Activated",
                      "12"= "pDC", 
                      "13"= "Eryth"
)
head(Idents(scobj))
### C.保存注释的结果
DimPlot(scobj, reduction = "umap", label = T)
metadata <- scobj@meta.data
scobj@meta.data$celltype = Idents(scobj)

### 保存注释前的数据
DimPlot(scobj, reduction = "umap", label = T)
saveRDS(scobj,file = "output/hamony_seurat_annotaion_newdata20230604.rds")

### 推荐阅读
### 要注意reduction指定的问题
### https://hbctraining.github.io/scRNA-seq_online/lessons/09_merged_SC_marker_identification.html
### https://satijalab.org/seurat/articles/integration_introduction.html
### https://satijalab.org/seurat/archive/v3.0/immune_alignment.html
### 解释CD4旁边的CD8
# Users familiarized with PBMC datasets may know that 
# CD8+ CCR7+ cells usually cluster next to CD4+ CCR7+ and separate from the rest of CD8+ cells. 
# Let’s aim to identify Naive CD8+ T cells
### http://htmlpreview.github.io/?https://github.com/satijalab/seurat-wrappers/blob/master/docs/nebulosa.html