################################################
### 作者：果子
### 更新时间：2023-06-03
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
library(Seurat)
## 1.读入数据
scdata <- Read10X(data.dir = "./data/10x/filtered_gene_bc_matrices/hg19/")

## 2.创建Seurat对象
scobj <- CreateSeuratObject(counts = scdata, 
                              project = "pbmc3k", 
                              min.cells = 3, 
                              min.features = 200)
## 3.数据预处理、降维、分群
# 国自然(NFS),劳斯莱斯(RR),最终幻想(Final Fantasy,FF)
library(dplyr)
scobj <- scobj  %>%
  NormalizeData() %>%  #归一化
  FindVariableFeatures() %>%  #筛选特征,找高变基因
  ScaleData() %>%  #标准化
  RunPCA()  %>% #降维
  RunUMAP(dims = 1:10) %>%  #非线性降维
  FindNeighbors() %>% #建立SNN
  FindClusters(resolution=0.5)  #分群5

DimPlot(scobj, reduction = "umap", label = TRUE)

## 4.注释
## 80%的精力
Idents(scobj) <- "seurat_clusters"
scobj <- RenameIdents(scobj,
                        "0"="Naive CD4+ T",
                        "1"="CD14+ Mono", 
                        "2"="Memory CD4+", 
                        "3"= "B cell", 
                        "4"= "CD8+ T", 
                        "5"= "FCGR3A+ Mono",
                        "6"= "NK", 
                        "7"= "DC", 
                        "8"= "Platelet"
)

## 5.可视化
DimPlot(scobj, reduction = "umap", label = T,repel = T)+NoLegend()

## Seurat 是学习单细胞的基石
## 需要掌握单细胞对象，知道每一步用的什么数据，做了什么操作，最终储存在哪里