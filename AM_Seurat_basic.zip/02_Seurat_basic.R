################################################
### 作者：果子
### 更新时间：2023-06-03
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com
rm(list = ls())
library(Seurat)
library(scCustomize)

################################################
### 1.读入数据
scdata <- Read10X(data.dir = "data/GSM5258385_SYSMH1/")
### scdata是一个稀疏矩阵(dgCMatrix)
class(scdata)
scdata[1:100,1:10]
as.matrix(scdata[1:100,1:10])
### 使用 object.size() 查看大小
object.size(scdata)
object.size(as.matrix(scdata))
object.size(as.matrix(scdata))/object.size(scdata)


################################################
### 2.创建Seurat对象
### counts 输入的是数据，行是基因，列是细胞
### project 参数输入的是项目名称,出现在metadata的orig.ident这一列
### min.cells 限定的是基因：每个基因在至少多少个细胞中出现
### min.features 限定的是细胞: 每个细胞中最少有多少个基因
scobj <- CreateSeuratObject(counts = scdata, 
                              project = "OSCC1", 
                              min.cells = 3, 
                              min.features = 200)
### 查看对象
### 如何探索
str(scobj)

################################################
### 3.数据质控
### 主要PercentageFeatureSet函数计算线粒体含量
### 人类使用pattern = "^MT-"，小鼠使用pattern = "^mt-"
scobj[["percent.mt"]] <- PercentageFeatureSet(scobj, pattern = "^MT-")

#scobj@meta.data$percent.mt = PercentageFeatureSet(scobj, pattern = "^MT-")$nCount_RNA

### 该操作会在metadata数据里面增加一列叫做percent.mt
metadata <- scobj@meta.data

### 质控数据可视化，使用VlnPlot函数
### nFeature_RNA, number of Feature, 每个细胞中有多少个基因
### nCount_RNA, number of counts, 每个细胞中有多少个counts
### percent.mt, 我们自己增加的列,  每个细胞中线粒体基因的比例
VlnPlot(scobj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

### 正式筛选，筛选的是细胞，最终细胞减少
### nFeature_RNA > 200
### nFeature_RNA < 2500
### percent.mt < 5
scobj <- subset(scobj, subset = nFeature_RNA > 200 & nFeature_RNA < 6000 & percent.mt < 25)

################################################
### 4.数据标准化: NormalizeData
### 先除以总数，再乘以系数，然后取log
scobj <- NormalizeData(scobj, normalization.method = "LogNormalize", scale.factor = 10000)
### 默认参数可以省略
scobj <- NormalizeData(scobj)

################################################
### 5.特征筛选(高变基因)FindVariableFeatureshttp://127.0.0.1:33557/graphics/plot_zoom_png?width=1200&height=900
scobj <- FindVariableFeatures(scobj, selection.method = "vst", nfeatures = 2000)
### 默认参数可以省略
scobj <- FindVariableFeatures(scobj)

### 高变基因可视化
### 使用VariableFeatures 函数提取高变基因
### 等同于 scobj@assays$RNA@var.features
top10 <- head(VariableFeatures(scobj), 10)
### 使用VariableFeaturePlot 画图
plot1 <- VariableFeaturePlot(scobj)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 + plot2

### 理解seurat中函数的本质: 从scobj里面提取数据，计算或者作图
### 要明确，每一次操作，都是以数据作为支撑的
data <- scobj@assays$RNA@meta.features
library(ggplot2)
ggplot(data,aes(vst.mean,vst.variance.standardized,color=vst.variable))+
  geom_point()+
  scale_color_manual(values = c("black","red"))+
  scale_x_log10() +
  theme_bw()+
  labs(x="Average Expression",y="Standardized Variance")

### 加标签
library(ggrepel)
ggplot(data,aes(vst.mean,vst.variance.standardized,color=vst.variable))+
  geom_point()+
  scale_color_manual(values = c("black","red"))+
  scale_x_log10() +
  theme_bw()+
  labs(x="Average Expression",y="Standardized Variance")+
  geom_text_repel(data=data[top10,],label=top10,color="black") 


### rest
################################################
### 6.缩放数据: ScaleData
### 降维之前的必备操作
scobj <- ScaleData(scobj, features = rownames(scobj))
### 如果不限定参数，只会缩放高变基因
### scobj <- ScaleData(scobj)
### 缩放后的数据存放在scobj@assays$RNA@scale.data,会很大,保存对象的时候可以删掉
scale.data <- scobj@assays$RNA$scale.data

### 缩放的效果是，基因的平均值是0，方差是1
### 验证
hist(apply(scale.data,1,mean))
hist(apply(scale.data,1,var))
### 或者更快的方案
hist(matrixStats::rowMeans2(scale.data))
hist(matrixStats::rowVars(scale.data))

################################################
### 7.PCA线性降维
### https://www.youtube.com/watch?v=FgakZw6K1QQ&t=684s&ab_channel=StatQuestwithJoshStarmer
scobj <- RunPCA(scobj, features = VariableFeatures(object = scobj))
DimPlot(scobj, reduction = "pca")

### PCA降维数据存放在scobj@reductions$pca中

pcadata = as.data.frame(scobj@reductions$pca@cell.embeddings)
ggplot(pcadata,aes(PC_1,PC_2,color="red"))+
  geom_point()

### 选择合适的PCA维度
ElbowPlot(scobj)

################################################
### 8.UMAP非线性降维
### 依赖PCA的结果
### https://pair-code.github.io/understanding-umap/
### dims = 1:10 由上一步确定
scobj <- RunUMAP(scobj, dims = 1:15)
DimPlot(scobj, reduction = "umap")

### UMAP降维数据存放在scobj@reductions$umap中
umapdata = as.data.frame(scobj@reductions$umap@cell.embeddings)
ggplot(umapdata,aes(umap_1,umap_2,color="red"))+
  geom_point()

################################################
### 9.聚类分群
### 找紧邻,dims = 1:10 跟UMAP相同
scobj <- FindNeighbors(scobj, dims = 1:15)
### 分群
scobj <- FindClusters(scobj, resolution = 0.5)
### 会在metadata中增加两列数据"RNA_snn_res.0.5" "seurat_clusters"
metadata <- scobj@meta.data

### 设置多个resolution选择合适的resolution
scobj <- FindClusters(scobj, resolution = seq(0.2,1.2,0.1))
metadata <- scobj@meta.data
library(clustree)
clustree(scobj)

### 选择特定分辨率得到的分群此处为RNA_snn_res.0.5
scobj@meta.data$seurat_clusters <- scobj@meta.data$RNA_snn_res.0.5
Idents(scobj) <- "seurat_clusters"
DimPlot(scobj, reduction = "umap", label = T)


### rest
################################################
### 10.分群注释(占据80%的分析时间)

### 先分大群, 如何知道群? marker哪里来
### http://bio-bigdata.hrbmu.edu.cn/CellMarker/
### B: "MS4A1", "CD79A"
### NK: "GNLY", "NKG7"
### T: "CD3E","CD8A","CD4","IL7R", 
### Monocyte: "CD14", "FCGR3A", "LYZ"
### DC "FCER1A"
### Platelet: "PPBP"

### 使用VlnPlot画marker小提琴图
VlnPlot(scobj, features = c("MS4A1", "CD79A"))
### 使用FeaturePlot画出特征分布图
FeaturePlot(scobj, features = c("MS4A1", "CD79A"), order = TRUE,ncol=2)

VlnPlot(scobj, features = c("GNLY", "NKG7"))
FeaturePlot(scobj, features = c("GNLY", "NKG7"), order = TRUE,ncol=2)

VlnPlot(scobj, features = c("CD3E","CD8A","CD4","IL7R"))
FeaturePlot(scobj, features = c("CD3E","CD8A","CD4","IL7R"), order = TRUE,ncol=2)

VlnPlot(scobj, features = c("CD14", "FCGR3A", "LYZ"))
FeaturePlot(scobj, features = c("CD14", "FCGR3A", "LYZ"), order = TRUE,ncol=2)

VlnPlot(scobj, features = c("FCER1A", "PPBP"))
FeaturePlot(scobj, features =  c("FCER1A", "PPBP"), order = TRUE,ncol=2)

### 汇总画图
marker_genes <- c("MS4A1", "CD79A",
                  "GNLY", "NKG7",
                  "CD3E","CD8A","CD4","IL7R", 
                  "CD14", "FCGR3A", "LYZ", 
                  "FCER1A",
                  "PPBP"
                  )
FeaturePlot(scobj, features = marker_genes, order = TRUE,ncol=5)

### 再确定细节
marker_genes <- c("CD3E","CD4","CD8A",
                  "CCR7","SELL","CREM","TCF7","S100A4")
marker_genes <- c("CCR7","SELL","CREM","TCF7")
marker_genes <- c("RPS12","FASLG")
FeaturePlot(scobj, features = marker_genes, order = TRUE,ncol=4)

### 不好确定的时候,换一种作图方式
library(Nebulosa)
marker_genes <- c("CCR7","SELL","TCF7","S100A4")
plot_density(scobj,features = marker_genes)+plot_layout(ncol = 2)

### 确定不了的时候自己分析maker
all_markers <- FindAllMarkers(object = scobj)

all_markers$rank <- all_markers$pct.1/all_markers$pct.2

saveRDS(all_markers,file = "output/Seurat_single_sample_all_markers.rds")
library(dplyr)
top10_markers <- all_markers %>%
  group_by(cluster) %>%
  arrange(desc(avg_log2FC))%>%
  slice(1:10) %>%
  ungroup() 

################################################
### 11.确定注释结果
### 三部曲
### A.确认群的个数
head(Idents(scobj))
Idents(scobj) <- "seurat_clusters"
### B.给每个群添加注释
scobj <- RenameIdents(scobj,
                      "0"="Naive CD4+ T",
                      "1"="CD14+ Mono", 
                      "2"="Memory CD4+", 
                      "3"= "B cell", 
                      "4"= "CD8+ T", 
                      "5"= "FCGR3A+ Mono",
                      "6"= "NK", 
                      "7"= "DC", 
                      "8"= "Platelet"
)
head(Idents(scobj))
### C.保存注释的结果
metadata <- scobj@meta.data
scobj@meta.data$celltype = Idents(scobj)
### 保存结果
saveRDS(scobj,file = "output/Seurat_single_sample_scobj.rds")

### rest
################################################
### 12.注释结果可视化
rm(list = ls())
scobj = readRDS(file = "output/Seurat_single_sample_scobj.rds")
DimPlot(scobj, reduction = "umap")
DimPlot(scobj, reduction = "umap", label = T)
DimPlot(scobj, reduction = "umap", label = T)+NoLegend()
scCustomize::DimPlot_scCustom(scobj, figure_plot = TRUE)

### 各个细胞群，如何画图展示？
FeaturePlot(scobj,features = "CD8A")
FeaturePlot(scobj,features = "percent.mt")
metadata = scobj@meta.data
### 以"CD14+ Mono" 为例

scobj@meta.data$cd14_mono = ifelse(metadata$celltype == "CD14+ Mono",1,0)
FeaturePlot(scobj,features = "cd14_mono")

### all cell types
rm(list = ls())
scobj = readRDS(file = "output/Seurat_single_sample_scobj.rds")
metadata = scobj@meta.data

design=model.matrix(~0+ metadata$celltype)
design <- as.data.frame(design)
colnames(design) = levels(metadata$celltype)

scobj@meta.data = cbind(scobj@meta.data,design)
FeaturePlot(scobj,features = levels(metadata$celltype))

FeaturePlot(scobj,features = c("CD8+ T","CD8A"),cols = c("lightgrey", "red"))

#####################
### 可视化展示DotPlot
### 因子来限定细胞的顺序
Idents(scobj) <- factor(Idents(scobj),levels = c( "B cell",
                                                  "NK",
                                                  "Naive CD4+ T", 
                                                 "Memory CD4+",
                                                 "CD8+ T",
                                                 "CD14+ Mono",
                                                 "FCGR3A+ Mono",
                                                 "DC",
                                                 "Platelet"))

markers.to.plot <- c("MS4A1", "CD79A",
                     "GNLY", "NKG7",
                     "CD3E","CD8A","CD4","IL7R", 
                     "CD14", "FCGR3A", "LYZ", 
                     "FCER1A",
                     "PPBP")
DotPlot(scobj, features = markers.to.plot, dot.scale = 8)
DotPlot(scobj, features = markers.to.plot, dot.scale = 8) + RotatedAxis()
DotPlot(scobj, features = markers.to.plot, dot.scale = 8) + coord_flip()+ RotatedAxis()

#####################
### Clustered_DotPlot
### 可以自己挑选marker来呈现
### 也可以使用FindAllMarkers批量提取marker
# library(future)
# plan("multisession", workers = 9)
# https://satijalab.org/seurat/articles/future_vignette.html

all_markers <- FindAllMarkers(object = scobj)
saveRDS(all_markers,file = "output/Seurat_single_sample_all_markers.rds")
library(dplyr)
top5_markers <- all_markers %>%
  group_by(cluster) %>%
  arrange(desc(avg_log2FC))%>%
  slice(1:5) %>%
  ungroup() %>%
  pull(gene) %>%
  unique()

DotPlot(scobj, features = top5_markers)+ coord_flip()+ RotatedAxis()
scCustomize::Clustered_DotPlot(scobj, features = top5_markers)

#####################
### marker 热图
DoHeatmap(scobj, features = top5_markers)

### Identity的大小修改，通过size参数
DoHeatmap(scobj, features = top5_markers,size = 3)

### 基因的大小修改theme(axis.text.y = element_text(size = 8))
DoHeatmap(scobj, features = top5_markers,size = 3)+
  theme(axis.text.y = element_text(size = 8))

### subset和downsample 可以随机取每个群的细胞数
DoHeatmap(subset(scobj, downsample = 50), features = top5_markers,size = 3)+
  theme(axis.text.y = element_text(size = 8))

?DoHeatmap
### 注意slot = "scale.data"
scobj@assays$RNA@scale.data <- matrix()
saveRDS(scobj,file = "output/Seurat_noscaledata_scobj.rds")
################################################
### 推荐阅读
### https://satijalab.org/seurat/articles/pbmc3k_tutorial.html
### 细胞亚群以及marker
### http://bio-bigdata.hrbmu.edu.cn/CellMarker/
### 理解UMAP
### https://pair-code.github.io/understanding-umap/
### PCA 原理
### https://www.youtube.com/watch?v=FgakZw6K1QQ&t=684s&ab_channel=StatQuestwithJoshStarmer
