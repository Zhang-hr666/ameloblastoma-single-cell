rm(list = ls())
library(Seurat)
library(harmony)
library(SeuratWrappers)

################################################
### 1.读入数据，有多少个就读入多少
data1 <- readRDS(file = "output/AM1_seurat.rds")
data2 <- readRDS(file = "output/AM2_seurat.rds")
data3 <- readRDS(file = "output/AM3_seurat.rds")



### 把数据变成list
data <- list(data1,data2,data3)

################################################
### 2.Merge 合并数据
scobj <- merge(x=data[[1]], y = data[-1])

## 删除所有data前缀的数据,释放空间
rm(list =  ls(pattern="data.*"))

################################################
### 3.数据质控
### 主要PercentageFeatureSet函数计算线粒体含量
### 人类使用pattern = "^MT-"，小鼠使用pattern = "^mt-"
scobj[["percent.mt"]] <- PercentageFeatureSet(scobj, pattern = "^MT-")

### 该操作会在metadata数据里面增加一列叫做percent.mt
metadata <- scobj@meta.data

### 质控数据可视化，使用VlnPlot函数
### nFeature_RNA, number of Feature, 每个细胞中有多少个基因
### nCount_RNA, number of counts, 每个细胞中有多少个counts
### percent.mt, 我们自己增加的列,  每个细胞中线粒体基因的比例
VlnPlot(scobj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

### 正式筛选，筛选的是细胞，最终细胞减少
### nFeature_RNA > 200
### nFeature_RNA < 2500
### percent.mt < 5
scobj <- subset(scobj, subset = nFeature_RNA > 200 & nFeature_RNA < 6500 & percent.mt < 25)

#################################################################
scobj <- NormalizeData(scobj)
scobj <- FindVariableFeatures(scobj, selection.method = "vst", nfeatures = 2000)
scobj <- ScaleData(scobj, features = rownames(scobj))
scobj <- RunPCA(scobj, features = VariableFeatures(object = scobj),reduction.name = "pca")
### 不进行批次矫正
scobj <- RunUMAP(scobj,reduction = "pca", dims = 1:20, reduction.name = "umap_naive")
##scobj <- RunUMAP(scobj,reduction = "pca", dims = 1:15, reduction.name = "umap_naive")
### 使用harmony进行批次矫正
####设置随机种子
set.seed(12)
### 默认reduction = "pca",group.by.vars参数输入的是批次信息,reduction.save 是结果保存的名称
scobj <- RunHarmony(scobj,reduction = "pca",group.by.vars = "orig.ident",reduction.save = "harmony")
scobj <- RunUMAP(scobj, reduction = "harmony", dims = 1:30,reduction.name = "umap")
####用group试一下
scobj <- RunHarmony(scobj,reduction = "pca",group.by.vars = "group",reduction.save = "harmony1")
scobj <- RunUMAP(scobj, reduction = "harmony1", dims = 1:30,reduction.name = "umap1")

p1 <- DimPlot(scobj, reduction = "umap_naive",group.by = "group")
p2 <- DimPlot(scobj, reduction = "umap1",group.by = "group")
p3 <- DimPlot(scobj, reduction = "umap",group.by = "group")
p1+p2+p3
p1+p3

scobj <- FindNeighbors(scobj, reduction = "harmony", dims = 1:30)

### 设置多个resolution选择合适的resolution
scobj <- FindClusters(scobj, resolution = seq(0.2,1.2,0.1))

### 多个分辨率的分群信息会保存在metadata中
metadata <- scobj@meta.data
library(clustree)
clustree(scobj)

### 选定分辨率0.5作为分群
scobj@meta.data$seurat_clusters <- scobj@meta.data$RNA_snn_res.0.5
Idents(scobj) <- "seurat_clusters"

### 作图展示
DimPlot(scobj, reduction = "umap", label = T)
### 学习Dimplot的两个重要参数 group.by 和split.by
### group.by, 在一张图中展示多个信息
DimPlot(scobj, reduction = "umap", group.by = "group")
### split.by, 分成多个信息来展示
DimPlot(scobj, reduction = "umap", split.by = "orig.ident")

### 保存数据
### 保存前瘦身,删除掉scale.data
scobj@assays$RNA@scale.data <- matrix()

### 当前的reduction信息
names(scobj@reductions)
### FeaturePlot 如果不限定reduction
### 先找umap, 再找tsne, 再找pca
FeaturePlot(scobj, features = "MS4A1", order = TRUE)
FeaturePlot(scobj, features = "MS4A1", order = TRUE,reduction = "umap_naive")
FeaturePlot(scobj, features = "MS4A1", order = TRUE,reduction = "umap")
### 删除掉多余的reduction 信息
scobj@reductions$umap_naive <- NULL
FeaturePlot(scobj, features = "MS4A1", order = TRUE)

### 保存注释前的数据
saveRDS(scobj,file = "output/AM_hamony_seurat_unannotaion.rds")

### 推荐阅读
### https://github.com/satijalab/seurat-wrappers
### https://satijalab.org/seurat/articles/integration_introduction.html
