################################################
### 作者：果子
### 更新时间：2023-01-01
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

### 注释结果可视化
rm(list = ls())
library(Seurat)
scobj <- readRDS(file = "数据整合/output/OSCC_DEL15_18hamony_seurat_annotaion.rds")

################################################
### Dimplot
DimPlot(scobj, reduction = "umap")
DimPlot(scobj, reduction = "umap", label = T)
DimPlot(scobj, reduction = "umap", label = T)+NoLegend()
scCustomize::DimPlot_scCustom(scobj, figure_plot = TRUE)

DimPlot(scobj, reduction = "umap",split.by = "group")
DimPlot(scobj, reduction = "umap",split.by = "group",label = T) + NoLegend()

################################################
### 比例改变
## 计算比例
data <- as.data.frame(table(scobj$group,scobj$celltype))
colnames(data) <- c("group","CellType","Freq")
library(dplyr)
df <- data %>% 
  group_by(group) %>% 
  mutate(Total = sum(Freq)) %>% 
  ungroup() %>% 
  mutate(Percent = Freq/Total) %>% 
  as.data.frame()

df$CellType  <- factor(df$CellType,levels = unique(df$CellType))

#write.csv(df,file = "output/cell_percent.csv",row.names = F,quote = F)

library(ggplot2)
p <- ggplot(df, aes(x = group, y = Percent, fill = CellType)) +
  geom_bar(position = "fill", stat="identity", color = 'white', alpha = 1, width = 0.95) +
  #scale_fill_manual(values = mycol) +
  scale_y_continuous(expand = c(0,0)) +
  theme_classic()
p

### 换种形式
### facet_wrap 可以设置行列参数
ggplot(df,aes(x = group, y = Percent,fill=group))+
  geom_bar(stat="identity")+
  facet_wrap(~ CellType,nrow = 2)+
  theme_bw()+
  NoLegend()

ggplot(df,aes(x = CellType, y = Percent,fill=group))+
  geom_bar(stat="identity")+
  facet_wrap(~ group,nrow = 2)+
  theme_bw()+
  NoLegend()

### 筛选数据 和前面seurat的subset比较，理解泛型函数
data <- subset(df,subset = !CellType %in% c("Mono/Mk Doublets","Mk","Eryth","DC","pDC"))
ggplot(data,aes(x = group, y = Percent,fill=group))+
  geom_bar(stat="identity")+
  facet_wrap(~ CellType,nrow = 3)+
  theme_bw()+
  NoLegend()

################################################
### 可视化展示DotPlot 和 Clustered_DotPlot
all_markers <- readRDS(file = "output/Seurat_stim_all_markers.rds")
library(dplyr)
top_markers <- all_markers %>%
  group_by(cluster) %>%
  arrange(desc(avg_log2FC))%>%
  slice(1:5) %>%
  ungroup() %>%
  pull(gene) %>%
  unique()

DotPlot(scobj, features = top_markers)
DotPlot(scobj, features = top_markers) + RotatedAxis()
DotPlot(scobj, features = top_markers) + coord_flip()+ RotatedAxis()
DotPlot(scobj, features = top_markers,dot.scale = 4) + coord_flip()+ RotatedAxis()+
theme(axis.text.y = element_text(size = 8))

scCustomize::Clustered_DotPlot(scobj, features = top_markers)

### 分组dotplot
### 注意事项, 不要在命名时出现+号，会导致画图失败，比如CD8+ T
dput(levels(Idents(scobj)))

### 调整顺序
Idents(scobj) <- factor(Idents(scobj), 
                        levels = c("Mono/Mk Doublets",
                                   "pDC", "Eryth", "Mk", "DC", 
                                   "CD14 Mono", "CD16 Mono", 
                                   "B Activated", "B cell", "CD8 T", 
                                   "NK", "T activated",
                                   "CD4 Naive T", "CD4 Memory T"))
### 选择作图基因
markers.to.plot <- c("CD3D", "CREM", "HSPH1", "SELL", "GIMAP5", "CACYBP", "GNLY", "NKG7", "CCL5",
                     "CD8A", "MS4A1", "CD79A", "MIR155HG", "NME1", "FCGR3A", "VMO1", "CCL2", "S100A9", "HLA-DQA1",
                     "GPR183", "PPBP", "GNG11", "HBA2", "HBB", "TSPAN13", "IL3RA", "IGJ", "PRSS57")
### 绘图,主要时候cols参数，给了两个颜色，split.by区分多组
DotPlot(scobj, features = markers.to.plot, 
        cols = c("blue", "red"), 
        dot.scale = 6, 
        split.by = "group") +
  RotatedAxis()+
  theme(axis.text.y = element_text(size = 8))+
  theme(axis.text.x = element_text(size = 8))

################################################
### marker 热图,需要scale data
scobj <- ScaleData(scobj, features = rownames(scobj))
DoHeatmap(scobj, features = top_markers)

### Identity的大小修改，通过size参数
DoHeatmap(scobj, features = top_markers,size = 3)

### 基因的大小修改theme(axis.text.y = element_text(size = 8))
DoHeatmap(scobj, features = top_markers,size = 3)+
  theme(axis.text.y = element_text(size = 8))

### subset和downsample 可以随机取每个群的细胞数
DoHeatmap(subset(scobj, downsample = 50), features = top_markers,size = 3)+
  theme(axis.text.y = element_text(size = 8))

library(scRNAtoolVis)
AverageHeatmap(object = scobj,markerGene = top_markers)
## 修改基因的字号
AverageHeatmap(object = scobj,markerGene = top_markers,fontsize = 8)
## 组间比较
AverageHeatmap(object = subset(scobj,group=="CTRL"),markerGene = top_markers,fontsize = 8)+
  AverageHeatmap(object = subset(scobj,group=="STIM"),markerGene = top_markers,fontsize = 8)
