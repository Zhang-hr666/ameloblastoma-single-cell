################### After SCENIC #######################
## Aims:
## 从SCENIC outputs到生物学假设
## Input data: PBMC (ctrl vs IFNB simulated)
## => 1. 受到IFNB影响最大的PBMC细胞类型是什么?        | cellular level
##    2. 哪些TF驱动了IFNB simulated PBMC的转录组变化? | Molecular level
##    3. 哪些TF驱动了哪些细胞类型的什么样的变化?
##       (下游的基因, related to某些生物学功能)       | Functional level
rm(list = ls())
library(Seurat)
library(tidyverse)
library(patchwork)
setwd(here::here())
source("R/compute_module_score.R")

## 导入Seurat对象
seu <- qs::qread("output/s")
# ####只纳入成纤维，上皮
# seu <- subset(seu, celltype %in% c("Epithelial", "Fibroblast"))
# DimPlot(seu, group.by = "celltype", reduction = "umap", label = T)
# celltype.levels <- c("Epithelial", "Fibroblast")
# seu$celltype <- factor(seu$celltype, levels = celltype.levels)
seu <- subset(seu, seurat_clusters %in% c("0", "1", "2", "4", "5",
                                          "6", "8", "9", "12", "13", "15"))
DimPlot(seu, group.by = "celltype", reduction = "umap", label = T)
celltype.levels <- c("E00", "E01", "E02", "E03", "E04","E05",
                     "E06", "E07", "E08", "E09", "E10",
                     "E11", "E12", "E13", "E14", "E15", "E16")
seu$celltype <- factor(seu$celltype, levels = celltype.levels)
## 导入regulon (gene list)
regulons <- clusterProfiler::read.gmt("output/02-ifnb_pbmc.regulons.gmt")
## data.frame -> list, list中的每个元素为一个gene set
rg.names <- unique(regulons$term)
regulon.list <- lapply(rg.names, function(rg) {
  subset(regulons, term == rg)$gene
})
names(regulon.list) <- sub("[0-9]+g", "\\+", rg.names)
summary(sapply(regulon.list, length))
print(regulon.list[1])
# saveRDS(regulon.list, "output/03-1.ifnb_AM.regulons.rds")

## 用AUCell计算RAS matrix
## RAS = regulon activity score
seu <- ComputeModuleScore(seu, gene.sets = regulon.list, min.size = 10, cores =10)
seu
DefaultAssay(seu) <- "AUCell"

p1 <- FeaturePlot(seu, features = "STAT2(+)", split.by = "group")
p2 <- FeaturePlot(seu, features = "STAT2", split.by = "group")
(p1 / p2) & scale_color_viridis_c()

VlnPlot(seu, group.by = "celltype", features = "STAT2(+)", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red")) + ylab("TF activity")
VlnPlot(seu, group.by = "celltype", features = "STAT2", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red"))

## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = rownames(seu),
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRAS",
               reduction.key = "umapRAS_")

seu <- RunTSNE(object = seu,
               features = rownames(seu),
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "TSNERAS",
               reduction.key = "TSNERAS_")



## 可视化：UMAP on harmony
p1 <- DimPlot(seu, reduction = "umap", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p2 <- DimPlot(seu, reduction = "umap", group.by = "group") + NoLegend()

## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "group")

(p1 + p3) / (p2 + p4)
## 可视化：tsne on RAS
p3 <- DimPlot(seu, reduction = "TSNERAS", group.by = "subcelltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "TSNERAS", group.by = "group")


## 推测：INFB对髓系细胞的影响更大
## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "seurat_clusters") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "patient",split.by = "celltype")
p4
(p1 + p3) / (p2 + p4)

## 换一种方式：PCA
DefaultAssay(seu) <- "AUCell"
seu <- ScaleData(seu)
seu <- RunPCA(object = seu,
              features = rownames(seu),
              reduction.name = "pcaRAS",
              reduction.key = "pcaRAS_")

## 可视化：PCA on RAS
p3 <- DimPlot(seu, reduction = "pcaRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "pcaRAS", group.by = "group")
p3 + p4

## PC1 encoding the regulons related to cell type
## PC2 encoding the regulons affected by INFB treatment
## The INFB induced transcriptome shift is orthogonal to the cell identity transcriptional programs.

VlnPlot(seu, group.by = "celltype", features = "pcaRAS_1", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red"))

VlnPlot(seu, group.by = "celltype", features = "pcaRAS_2", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red"))

qs::qsave(seu, "output/03-2.AMepi_1.0.seurat.qs")


###########################
seu <- qs::qread("output/03-2.AMepi_1.0.seurat.qs")
Idents(seu) <- "celltype"
seu1 <- subset(seu,idents =c("E06","E13"))
p3 <- DimPlot(seu1, reduction = "pcaRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu1, reduction = "pcaRAS", group.by = "group")
p3 + p4
p3 <- DimPlot(seu1, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu1, reduction = "umapRAS", group.by = "group")
p3 + p4


