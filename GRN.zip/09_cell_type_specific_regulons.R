#### 细胞类型特异的regulon ####
## 问题: 特定细胞的身份是哪些TFs维持的?

options(stringsAsFactors = F)
library(Seurat)
library(tidyverse)
library(data.table)
library(ggrepel)
# philentropy包用于计算JS散度，关于这个package的详细介绍在此：http://blog.fens.me/r-entropy/
library(philentropy) # install.packages("philentropy")
source("R/regulon_specificity.R")

#### 计算RSS矩阵(Regulon Specificity Score) ####

## The RSS
a <- c(0.7, 0.5, 0.1, 0.1, 0) # TF activity score
## cell type: a,a,b,b,c
b1 <- c(1, 1, 0, 0, 0) # cell type a
b2 <- c(0, 0 ,1, 1, 0) # cell type b
b3 <- c(0, 0, 0, 0, 1) # cell type c

1 - philentropy::JSD(rbind(a, b1), unit = 'log2', est.prob = "empirical")
1 - philentropy::JSD(rbind(a, b2), unit = 'log2', est.prob = "empirical")
1 - philentropy::JSD(rbind(a, b3), unit = 'log2', est.prob = "empirical")
cor(a, b1, method = )

## 注意，这里我们使用对照组来计算，简化对数据的解释
seu <- qs::qread("output/03-2.AMepi_1.0.seurat.qs")
seu <- subset(seu, celltype.levels == "CTRL")
DefaultAssay(seu) <- "AUCell"

# rows are cells and columns are features (regulons)
rasMat <- t(seu[["AUCell"]]@data)
dim(rasMat)

## 2.2 计算cell type indicate matrix
ctMat <- calIndMat(seu$celltype)
dim(ctMat)

## 2.3 计算RSS matrix
rssMat <- calRSSMat(rasMat, ctMat)
dim(rssMat)

## 2.4 可视化

## Overall
plot.list <- lapply(levels(seu$celltype), function(xx) {
  PlotRegulonRank(rssMat, xx)
})
cowplot::plot_grid(plotlist = plot.list, ncol = 6)

## Specific cases
PlotRegulonRank(rssMat, "E00")
FeaturePlot(seu, reduction = "umap", features = "IRF8(+)")
DimPlot2(seu, reduction = "umap", group.by = "celltype", group.highlight = "DC") +
DimPlot2(seu, reduction = "umap", regulon = "RUNX2(+)")
DimPlot2(seu, reduction = "umap", regulon = "RUNX2(+)", threshold = 0.03)

PlotRegulonRank(rssMat, "B cell")
FeaturePlot(seu, reduction = "umap", features = "EBF1(+)")
DimPlot2(seu, reduction = "umap", group.by = "celltype", group.highlight = "B cell") +
DimPlot2(seu, reduction = "umap", regulon = "EBF1(+)")
