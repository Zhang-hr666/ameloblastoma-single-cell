### 作者：果子
### 更新时间：2022-10-05
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
##############################################################
### GSEA 分析
load(file = "output/DEseq2_ESR1_Diff.Rdata")
library(dplyr)
gene_df <- res %>% 
  dplyr::select(gene_id,logFC,gene) %>% 
  ## 去掉NA
  filter(gene!="") %>% 
  ## 去掉重复
  distinct(gene,.keep_all = T)

### 1.获取基因logFC
geneList <- gene_df$logFC
### 2.命名
names(geneList) = gene_df$gene
## 3.排序很重要
geneList = sort(geneList, decreasing = TRUE)

head(geneList)
library(clusterProfiler)

## 读入hallmarks gene set，从哪来？
hallmarks <- read.gmt("resource/h.all.v2022.1.Hs.symbols.gmt")
### GSEA 分析
gseahallmarks <- GSEA(geneList,TERM2GENE =hallmarks)
### 查看富集的表格
yd <- as.data.frame(gseahallmarks)

library(ggplot2)
dotplot(gseahallmarks,
        showCategory=50,
        label_format = 60,
        split=".sign")+facet_grid(~.sign)

library(enrichplot)
pathway.id = "HALLMARK_ESTROGEN_RESPONSE_EARLY"
gseaplot2(gseahallmarks, 
          color = "red",
          geneSetID = pathway.id,
          pvalue_table = T)

pathway.id = "HALLMARK_IL6_JAK_STAT3_SIGNALING"
gseaplot2(gseahallmarks, 
          color = "red",
          geneSetID = pathway.id,
          pvalue_table = T)

### 转录组数据还可以参考这个帖子
### https://mp.weixin.qq.com/s/7BBJGTlOa5i6YPMlrRqw2w
### 如果进一步学习
### https://yulab-smu.top/biomedical-knowledge-mining-book/index.html
