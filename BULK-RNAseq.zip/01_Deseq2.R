### 作者：果子
### 更新时间：2022-10-05
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
### 重点内容！
### 使用Deseq2进行转录组数据下游分析，总共9步
#########################################################
### https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE153250
### 1.读入表达矩阵
### 表达矩阵哪里来？
### 要求, 行数基因，列是样本，内容是counts(非负整数)

exprSet <- read.csv("data/AMandn_expr.csv")

#########################################################
### 2.准备 metadata文件
### (用于注释样本信息，至少两列，一列是样本名称，一列是分组信息)
metadata <- read.csv("data/all_metadata.csv")
# metadata <- data.table::fread("data/metadata.txt",data.table = F,header = F)
# rownames(metadata) <- metadata[,1]
# metadata <- metadata[colnames(exprSet)[-1],]
# ### 添加分组信息
# metadata$group <- ifelse(grepl("ESR1",metadata$V2),"treat","control")
# 
# metadata = metadata[,c(1,3)]
# colnames(metadata) <- c("sample","group")
save(metadata,file = "output/metadata.Rdata")
#########################################################
### 3.核心环节，构建dds对象，前面的操作都是铺垫
### 要记住四个参数
### 要有数据countData，这里就是exprSet
### 要有分组信息，在colData中，这里是metadata
### design部分是分组信息，格式是~group,没有分组设置为~1
### 第一列如果是基因名称，需要自动处理，设置参数tidy=TRUE
### 对象是个复合体
library(DESeq2)
dds <-DESeqDataSetFromMatrix(countData=exprSet, 
                             colData=metadata, 
                             design=~group+batch,
                             tidy=TRUE)
nrow(dds)
rownames(dds)
### 筛选样本，counts函数提取表达量数据
dds <- dds[rowSums(counts(dds))>1,]
nrow(dds)

#########################################################
### 4.数据质量判断
### vst标准化处理
### ?varianceStabilizingTransformation
vsd <- vst(dds, blind = FALSE)
### 内置函数plotPCA进行主成分分析画图
plotPCA(vsd, "group")

### 用内置函数plotCounts来进行快速，简易作图
### 找到阳性基因,此处ESR1
### dds来自于上一步
### gene 输入的是ensemble ID
### intgroup 输入的是metadata中分组信息
plotCounts(dds, gene = "ENSG00000091831", intgroup=c("group"))

### 导出标准化后的表达数据
### assay函数提取vst标准化后的数据，保存数据用于热图
exprSet_vst <- as.data.frame(assay(vsd))
test <- exprSet_vst[1:10,1:10]
### 保存数据,用于表达量作图，比如差异分析，热图
save(exprSet_vst,file = "output/exprSet_vst.Rdata")

#########################################################
### 5.正式运行DESeq主程序
### 依次经过下面几步
### estimating size factors
### estimating dispersions
### gene-wise dispersion estimates
### mean-dispersion relationship
### final dispersion estimates
### fitting model and testing
dds <- DESeq(dds)

#########################################################
### 6.logFC矫正，RNAseq很重要的一步

### contrast参数设置
### 依次是，1.分组信息(metadata中的列) 2.处理组，3.对照组
contrast=c("group", "treat", "control")
### results函数获取差异分析的结果
### ?results
dd1 <- results(dds, contrast=contrast, alpha = 0.05)
### 内置函数plotMA作图
plotMA(dd1, ylim=c(-5,5))
### logFC矫正
### install.packages("ashr")
dd2 <- lfcShrink(dds,contrast=contrast, res=dd1,type="ashr")
plotMA(dd2, ylim=c(-5,5))

#########################################################
### 7.导出差异分析的结果
library(dplyr)
library(tibble)
library(tidyr)
res <- dd2 %>% 
  as.data.frame() %>% 
  rownames_to_column("gene_id") 
#save(res,file = "res_anno_demo.Rdata")
#########################################################
### 8.基因注释
### 当前基因名称是ENSEMBL
library(AnnotationDbi)
library(org.Hs.eg.db)
### 增加基因名称SYMBOL
res$symbol <- mapIds(org.Hs.eg.db,
                     keys=res$gene_id,
                     column="SYMBOL",
                     keytype="ENSEMBL",
                     multiVals="first")
### 增加ENTREZID
res$entrez <- mapIds(org.Hs.eg.db,
                     keys=res$gene_id,
                     column="ENTREZID",
                     keytype="ENSEMBL",
                     multiVals="first")
### 修改logFC，p值的名称，为的是跟火山图的代码匹配
colnames(res) <- c("gene_id","AveExpr","logFC","lfcSE","P.Value","adj.P.Val","gene","entrez")

#########################################################
### 9.保存数据
save(res,file = "output/DEseq2_ESR1_Diff.Rdata")
