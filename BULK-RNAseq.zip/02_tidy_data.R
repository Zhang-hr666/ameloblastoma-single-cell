### 作者：果子
### 更新时间：2021-07-20
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

rm(list = ls())
### 本节任务: 转录组数据变成清洁数据
###################################################################
### 一个基因，或者多个基因的差异作图
### 需要清洁数据
### 1.vst后的数据
load("output/exprSet_vst.Rdata")
### 2.差异分析结果
load("output/DEseq2_ESR1_Diff.Rdata")
### 3.分组费逆袭
load("output/metadata.Rdata")

########################################
### 获取清洁数据
### 1.获取注释文件
library(dplyr)
ensemble_symbol = res %>% 
  dplyr::select(gene_id,gene) %>% 
  filter(gene !="") 

### 2.准备表达量数据
### 行名变成列
exprSet <- cbind(gene_id=rownames(exprSet_vst),exprSet_vst)

### 3.交叉合并
exprSet <- merge(ensemble_symbol,exprSet,by="gene_id")

### 4.基因名称去重(保留最大值法)
### 列转行名一定要去重，因为行名不支持重复
exprSet <- exprSet %>% 
  dplyr::select(-gene_id) %>% 
  mutate(newcolumn = rowMeans(.[,-1])) %>% 
  arrange(desc(newcolumn)) %>% 
  distinct(gene,.keep_all = T) %>% 
  dplyr::select(-newcolumn)

### 5.列变成行名
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
### 保存数据，画热图
save(exprSet,file = "output/exprSet_heatmap.Rdata")

### 6.行列转置
exprSet <- t(exprSet)
exprSet <- as.data.frame(exprSet)
test <- exprSet[,1:10]

### 7.添加分组
exprSet <- cbind(group= metadata$group,exprSet)
test <- exprSet[,1:10]
save(exprSet,file = "output/exprSet_tidy.Rdata")

###########################################################
### 清洁数据探索
rm(list = ls())
load(file = "data/exprSet_AMSeleted1tidy.Rdata")

## steal plot
my_comparisons <- list(
  c("treat", "control")
)
library(ggpubr)
ggboxplot(
  exprSet, x = "group", y = "ESR1",
  color = "group", palette = c("#00AFBB", "#E7B800"),
  add = "jitter"
)+
  stat_compare_means(comparisons = my_comparisons, method = "t.test")

## 改写成函数
diffplot <- function(gene){
  my_comparisons <- list(
    c("treat", "con")
  )
  library(ggpubr)
  ggboxplot(
    exprSet, x = "group", y = gene,
    color = "group", palette = c("#00AFBB", "#E7B800"),
    add = "jitter"
  )+
    stat_compare_means(comparisons = my_comparisons, method = "t.test")
}

### AGR3,ESR1,SLC4A10, ALPP,VSIR,PLA2G2F
####wnt "CAMK2B, TLE2, TCF7, SFRP1, DKK4, WNT6, CCND2, MMP7, RSPO3, WNT7A, FZD7, FRZB, FZD5, CXXC4, ROR2, FZD8, ZNRF3, APCDD1L, LGR4"
diffplot("CAMK2B")
diffplot("ALPP")

## 多个基因作图查看
## 先把基因提取出来
genelist <- c("CAMK2B", "TLE2", "TCF7", "SFRP1", "DKK4", "WNT6",
"CCND2", "MMP7","RSPO3", "WNT7A", "FZD7",
"FRZB", "FZD5", "CXXC4", "ROR2", 'FZD8', 'ZNRF3', 'APCDD1L','LGR4')
## 再提取表达量，使用名称选取行
data <- exprSet[,c("group",genelist)]
## 用pivot_longer调整数据，数据变长，增加的是行
library(tidyr)
data <- data %>% 
  pivot_longer(cols=-1,
               names_to= "gene",
               values_to = "expression")
## 多基因作图
## 作图

ggplot(data = data, aes(x = group, y = expression, fill = group)) +
  geom_boxplot() +
  theme_bw() +
  facet_grid(. ~ gene) +
  theme(axis.text.x = element_text(angle = 20, hjust = 0.5)) +
  scale_fill_manual(values = c("Primary" = "#00CCCC", "Recurrent" = "#FF0033")) + 
  stat_compare_means(comparisons = my_comparisons, label = "p.signif", method = "t.test")
######hippo信号
genelist <- c("WWTR1", "GLI2", "TCF7", "BMP7", "WNT6", "CCND2", "DLG2", "WNT7A", "FZD7", "FZD5", "RASSF6", "FZD8")
## 再提取表达量，使用名称选取行
data <- exprSet[,c("group",genelist)]
## 用pivot_longer调整数据，数据变长，增加的是行
library(tidyr)
data <- data %>% 
  pivot_longer(cols=-1,
               names_to= "gene",
               values_to = "expression")
## 多基因作图
ggplot(data = data, aes(x = group, y = expression, fill = group)) +
  geom_boxplot() +
  theme_bw() +
  facet_grid(. ~ gene) +
  theme(axis.text.x = element_text(angle = 20, hjust = 0.5)) +
  scale_fill_manual(values = c("Primary" = "#00CCCC", "Recurrent" = "#FF0033")) + 
  stat_compare_means(comparisons = my_comparisons, label = "p.signif", method = "t.test")




