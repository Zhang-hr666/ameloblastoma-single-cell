rm(list = ls())
data <- read.csv(file = "output/allam_n.csv")
options(stringsAsFactors = F)
########## 加载R包
library(glmnet)
library(survival)
library(dplyr)
library(tidyr)
library(tibble)
library(survminer)
library(ggplot2)
library(pheatmap)
library(cowplot)
library(timeROC)
library(survivalROC)
library(caret)
library(rms)
library(foreign)

lassoGene <- c("JUND","BACH2",'CUX2','LEF1','ATF3','GRHL2','ZNF235','RARB','MYEF2')
###三、多因素Cox回归建模

coxdata <- cbind(data[,1:2],data[,lassoGene])
colnames(coxdata)[1] <- "OS"
colnames(coxdata)[2] <- "OS.time"
# ddist <- datadist(coxdata) #将数据打包
# options(datadist="ddist")
units(coxdata$OS.time) <- "day" #定义时间的单位
# paste(colnames(coxdata)[-c(1:2)], collapse = " + ")
# paste0("Surv(OS,OS.Status) ~ ", paste(colnames(coxdata)[-c(1:2)], collapse = " + "))
## cph函数优雅的方式
# cox_result <- cph(as.formula(paste0("Surv(OS,OS.Status) ~ ", paste(colnames(coxdata)[-c(1:2)], collapse = " + "))),
#                x=T,y=T,surv=T,data=coxdata)
#cox_result <- step(cox_result,direction = "both") #逐步回归

cox_result <- coxph(Surv(OS.time, OS) ~ .,data = coxdata) #用另外一种方式：coxph函数构建模型
#cox_result <- step(cox_result,direction = "both") #逐步回归,可用可不用

##  保存，coe用于计算训练集、测试集的风险评分
# save(cox_result,file = "./output/multiCox_result.Rdata")  
# load(file = "./output/multiCox_result.Rdata")

summary_cox <- summary(cox_result)

multiCox_HR <- cbind(coef = summary_cox$coefficients[,"coef"],
                     HR=signif(summary_cox$conf.int[,"exp(coef)"],digits = 2), #保留2位置小数
                     HR.confint.lower = signif(summary_cox$conf.int[,"lower .95"],digits = 2),
                     HR.confint.upper = signif(summary_cox$conf.int[,"upper .95"],digits = 2),
                     pvalue = signif(summary_cox$coefficients[,"Pr(>|z|)"],digits = 2))

multiCox_HR <- as.data.frame(multiCox_HR)
multiCox_HR$CI <- paste0("(", multiCox_HR$HR.confint.lower, "-", multiCox_HR$HR.confint.upper, ")")
colnames(multiCox_HR)[6] <- "95% CI"
multiCox_HR <- multiCox_HR %>% 
  rownames_to_column("Gene")

write.table(multiCox_HR,file="./output/resting_multiCox_HR.xls",sep="\t",row.names=F,quote=F)
save(multiCox_HR,file = "./output/resting_multiCox_HR.Rdata")

## 计算cox回归的风险评分
index <- as.character(multiCox_HR$Gene)
coxdata <- cbind(coxdata[,1:2],coxdata[,index])
coxdata$ISP <- predict(cox_result,type="risk",newdata=coxdata)
save(coxdata,file = "./output/resting_coxdata.Rdata") #保存一下cox回归的结果

## 风险评分的HR
#load(file = "./output/coxdata.Rdata")

cutoff <- median(coxdata$ISP)
coxdata$ISP_group <- ifelse(coxdata$ISP > cutoff, "ISP high","ISP low")
table(coxdata$ISP_group)
coxdata$ISP_group <- factor(coxdata$ISP_group, levels = c("ISP low", "ISP high"))
x = coxph(Surv(OS.time, OS) ~ISP_group, data = coxdata)###ISP小坑ISP_group
x = summary(x)
p.value=signif(x$wald["pvalue"], digits=2)
HR =signif(x$coef[2], digits=2);#exp(beta)
HR.confint.lower = signif(x$conf.int[,"lower .95"], 2)
HR.confint.upper = signif(x$conf.int[,"upper .95"],2)


######  四、开始KM生存分析
rm(list = ls())
library(survival)
library(survminer)
load(file = "./output/resting_coxdata.Rdata") 
risk_data <- coxdata
## part1.按照原文用中位数
###如果上一步为分组HR，这里直接算fit
cutoff <- median(risk_data$ISP)

risk_data$ISP_group <- ifelse(risk_data$ISP > cutoff, "ISP high","ISP low")
table(risk_data$ISP_group)

fit <- survfit(Surv(OS.time, OS) ~ ISP_group, data = risk_data)

p1  <-  ggsurvplot(fit,
                   legend.title = substitute('Recurrent Risk Score'),  # 使用 substitute 将变量嵌入字符串
                   legend.labs = c("high","low"),
                   #legend = "top",#图例位置
                   pval = T,
                   pval.method = TRUE,#添加p值的检验方法
                   # conf.int.alpha=0.1,#透明度
                   # conf.int = TRUE,#添加置信区间
                   risk.table = F, #在图下方添加风险表
                   risk.table.col = "strata", #根据数据分组为风险表添加颜色
                   risk.table.y.text = F,#风险表Y轴是否显示分组的名称,F为以线条展示分组
                   #linetype = "strata", #改变不同组别的生存曲线的线型
                   #surv.median.line = "hv", #标注出中位生存时间
                   xlab = "Time in day", #x轴标题
                   #xlim = c(0,max(risk_data$OS.time)), #展示x轴的范围
                   ylab = "Overall Recurrent rate",
                   break.time.by = 1000, #x轴间隔
                   size = 1, #线条大小
                   #ggtheme = theme_bw(), #为图形添加网格
                   palette = c("#DAA520","#00BFFF")#图形颜色风格
) 

#看一下图
p1  
###保存之前改一下risk_data中的列名，注意Fcelltype是动态变量
# 修改列名
colnames(risk_data)[colnames(risk_data) == "ISP"] <- Fcelltype
colnames(risk_data)[colnames(risk_data) == "ISP_group"] <- paste(Fcelltype, "_group", sep = "")
#保存
library(export)
graph_output_path <- paste("output/OSCC_subsetFibmark/", Fcelltype, "_group.OS.pdf", sep = "")
data_output_path <- paste("output/OSCC_subsetFibmark/", Fcelltype, "_risk_data.Rdata", sep = "")
csv_output_path <- paste("output/OSCC_subsetFibmark/", Fcelltype, "_risk_data.csv", sep = "")
csv1_output_path <- paste("output/OSCC_subsetFibmark/", Fcelltype, "_multiCox_HR.csv", sep = "")

graph2pdf(file = graph_output_path, width = 6, height = 6)
save(risk_data, file = data_output_path)
write.csv(risk_data, file = csv_output_path)
write.csv(multiCox_HR, file = csv1_output_path, row.names = FALSE)

## part2.按照用最佳cutoff值
risk_data <- coxdata
res.cut <- surv_cutpoint(risk_data,
                         time ="OS.time",
                         event = "OS",
                         variables = "ISP",
                         minprop = 0.3)
res.cut

cutoff=res.cut$cutpoint$cutpoint

risk_data$ISP_group <- ifelse(risk_data$ISP > cutoff, "ISP high","ISP low")
table(risk_data$ISP_group)

fit <- survfit(Surv(OS.time, OS) ~ ISP_group, data = risk_data)

ggsurvplot(fit,
           legend.title = "",#定义图例的名称
           legend.labs = c("ISP high","ISP low"),
           #legend = "top",#图例位置
           pval = T,
           pval.method = TRUE,#添加p值的检验方法
           #conf.int = TRUE,#添加置信区间
           risk.table = F, #在图下方添加风险表
           risk.table.col = "strata", #根据数据分组为风险表添加颜色
           risk.table.y.text = F,#风险表Y轴是否显示分组的名称,F为以线条展示分组
           #linetype = "strata", #改变不同组别的生存曲线的线型
           #surv.median.line = "hv", #标注出中位生存时间
           xlab = "Time in years", #x轴标题
           xlim = c(0,max(risk_data$OS.time)), #展示x轴的范围
           ylab = "Overall survival rate",
           break.time.by = 1, #x轴间隔
           size = 1, #线条大小
           #ggtheme = theme_bw(), #为图形添加网格
           palette = c("#DAA520","#00BFFF")#图形颜色风格
)
#
# #看一下图
# p1
