### 作者：果子
### 更新时间：2022-10-05
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

### 本节任务：KEGG分析
rm(list = ls())
library(clusterProfiler)
load(file = "output/DEseq2_AM_Seleted1Diff.Rdata")
### 筛选差异基因
library(dplyr)
diffgene <- res %>% 
  filter(gene !="") %>% 
  filter(adj.P.Val < 0.05) %>% 
  filter(abs(logFC) > 1)



##############################################################
#**KEGG分析**
##############################################################
EGG <- enrichKEGG(gene = diffgene$entrez,
                  organism = 'hsa',
                  pvalueCutoff = 0.05)
KEGG_df <- as.data.frame(EGG)
## 画图
barplot(EGG)
dotplot(EGG)
KEGG_df$geneID
###########################转换geneid
# 创建一个空的向量存储转换后的基因符号
gene_symbols <- c()

# 遍历KEGG_df$geneID中的每个基因ID
for (gene_ids_row in KEGG_df$geneID) {
  # 将基因ID拆分为单个ID
  gene_ids <- strsplit(gene_ids_row, "/")[[1]]
  # 初始化一个空的向量存储单个ID对应的基因符号
  symbols <- c()
  # 遍历单个基因ID
  for (gene_id in gene_ids) {
    # 在diffgene数据框中查找与基因ID匹配的行
    matched_row <- diffgene[diffgene$entrez == as.numeric(gene_id), ]
    # 如果找到匹配的行，则将基因符号添加到symbols向量中
    if (nrow(matched_row) > 0) {
      symbols <- c(symbols, matched_row$gene)
    }
  }
  # 将单个基因ID对应的所有基因符号组合成一个字符串，并用逗号分隔
  gene_symbols <- c(gene_symbols, paste(symbols, collapse = ", "))
}

# 将转换后的基因符号添加到KEGG_df数据框中
KEGG_df$gene <- gene_symbols

# 打印转换后的数据框
print(KEGG_df)
######################################################################

### KEGG的富集分析比较特殊，他的背后是个网站

browseKEGG(EGG, 'hsa04151')

### pathview需要的genelist
library(clusterProfiler)
diffgene <- res %>% 
  filter(gene !="") %>% 
  filter(adj.P.Val < 0.05) %>% 
  filter(abs(logFC) >1)

## geneList 三部曲
## 1.获取基因logFC
geneList <- diffgene$logFC
## 2.命名
names(geneList) = diffgene$entrez
## 3.排序很重要
geneList = sort(geneList, decreasing = TRUE)

head(geneList)
############################################################################
### pathview可视化
library(pathview)
pathway.id = "hsa04151"
pv.out <- pathview(gene.data  = geneList,
                   pathway.id = pathway.id,
                   species    = "hsa")

#########################################################################
### pathview批量画图
### 新建文件夹，
dir.create("output/pathview_out")
### 设置工作目录到想要的地方
getwd()
### 然后循环绘图
for (pathway.id in KEGG_df$ID ){
  pathview(gene.data  = geneList,
           pathway.id = pathway.id,
           species    = "hsa"
  )
}

### 结束后切换回原来的工作目录
### 确认
getwd()

##########################################################################
### 多组同时做
### 比如: 上调基因，下调基因，所有差异基因
### 函数 compareCluster
rm(list = ls())
library(clusterProfiler)
library(dplyr)
library(tibble)

load(file = "output/DEseq2_ESR1_Diff.Rdata")
diffgene <- res %>% 
  filter(gene !="") %>% 
  filter(adj.P.Val < 0.05) %>% 
  arrange(desc(logFC))

upgeneall <- diffgene$gene[diffgene$logFC>0]
dngeneall <- diffgene$gene[diffgene$logFC<0]

## 选取一定数目上调基因
upgene = head(upgeneall,3000)
## 选取一定数目下调基因
dngene = tail(dngeneall,3000)

## 输入文件
gcSample = list(up = upgene,
                down = dngene,
                all = c(upgene,dngene))

## 基因集 
h_df <- read.gmt("resource/h.all.v2022.1.Hs.symbols.gmt")

## 万能代码！！
xx <- compareCluster(gcSample, fun="enricher",TERM2GENE = h_df)
## 作图
dotplot(xx)
dotplot(xx,showCategory = 30)


################################################
### compareCluster extension
### 2022年10月5日,即兴
generate_genes <- function(number){
  ## 选取一定数目上调基因
  upgene = head(upgeneall,number)
  ## 选取一定数目下调基因
  dngene = tail(dngeneall,number)
  ## 输入文件
  gcSample = data.frame(group= c(rep("up",number),rep("down",number),rep("all",number*2)),
                        genes = c(upgene,dngene,c(upgene,dngene)),
                        num = number)
  return(gcSample)
}


mydata <- do.call("rbind",lapply(c(500,1000,1500,2000),generate_genes))
# mydata$group <- factor(mydata$group,levels = c("up","down","all"))
# mydata$num <- factor(mydata$num,levels = c("500","1000","1500","2000"))

xx <- compareCluster(genes~group+num, data=mydata, fun="enricher",TERM2GENE = h_df)
dotplot(xx)
dotplot(xx,showCategory = 30)
xx@compareClusterResult$num <- factor(xx@compareClusterResult$num,
                                      levels = c("500","1000","1500","2000"))
xx@compareClusterResult$group <- factor(xx@compareClusterResult$group,
                                      levels = c("up","down","all"))
library(ggplot2)
dotplot(xx,showCategory = 30,x = "group")+
  facet_grid(~num)

dotplot(xx,showCategory = 30,
        label_format = 60,
        x = "num")+
  facet_grid(~group)
########################看一下WNT信号展示图



