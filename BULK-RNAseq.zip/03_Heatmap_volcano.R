### 作者：果子
### 更新时间：2021-06-22
### 微信公众号:果子学生信
### 私人微信：guotosky
### 个人博客: https://codingsoeasy.com/
### 个人邮箱：hello_guozi@126.com

### 本节任务：如何展示一群基因的表达结果
### 热图！
###############
### heatmap热图
#用行名提取数据
rm(list = ls())
### 加载表达数据，这是vst标准化后的数据
load(file = "output/exprSet_heatmap.Rdata")
### 加载差异基因列表
load(file = "output/DEseq2_ESR1_Diff.Rdata")
### 筛选差异基因
library(dplyr)
diffgene <- res %>% 
  filter(gene !="") %>% 
  filter(adj.P.Val < 0.05) %>% 
  filter(abs(logFC) >2)
save(diffgene,file = "output/diffgene.Rdata")

### 加载热图的R包
library(pheatmap)
### 用名称提取部分数据用作热图绘制
heatdata <- exprSet[diffgene$gene,]

### 制作一个分组信息用于注释
load(file = "output/metadata.Rdata")

annotation_col <- data.frame(group=metadata$group)
rownames(annotation_col) <- metadata$sample

### 直接作图
pheatmap(heatdata)

### 如果注释出界, 可以通过调整格子比例和字体修正
pheatmap(heatdata, #热图的数据
         cluster_rows = TRUE,#行聚类
         cluster_cols = TRUE,#列聚类，可以看出样本之间的区分度
         annotation_col =annotation_col, #标注样本分类
         annotation_legend=TRUE, # 显示注释
         show_rownames = F,# 显示行名
         show_colnames = F,# 显示行名
         scale = "row", #以行来标准化，这个功能很不错
         color =colorRampPalette(c("blue", "white","red"))(100),#调色
         #filename = "heatmap_F.pdf",#是否保存
         cellwidth = 25, cellheight = 0.5,# 格子比例
         fontsize = 10)

### 加载R包
library(export)
### 导成PPT可编辑的格式
graph2ppt(file="output/heatmap.pptx")


################################################################
### 如何展示所有的基因变化
### 火山图
library(ggplot2)
library(ggrepel)
### 无论是什么名称，都改为data
data <- res
## 仔细观察data数据
## 如果是你自己的数据，至少有三列
## logFC，P.Value，gene
### 火山图
logFCfilter = 1.5
logFCcolor = 3.5
### 标记上下调
index = data$adj.P.Val <0.05 & abs(data$logFC) > logFCfilter
data$group <- 0
data$group[index & data$logFC>0] = 1
data$group[index & data$logFC<0] = -1
data$group <- factor(data$group,levels = c(1,0,-1),labels =c("Up","NS","Down") )
### 正式画图
ggplot(data=data, aes(x=logFC, y =-log10(adj.P.Val),color=group)) +
  geom_point(alpha=0.8, size=1.2)+
  scale_color_manual(values = c("red", "grey50", "blue4"))+
  labs(x="log2 (fold change)",y="-log10 (adj.P.Val)")+
  theme(plot.title = element_text(hjust = 0.4))+
  geom_hline(yintercept = -log10(0.05),lty=4,lwd=0.6,alpha=0.8)+
  geom_vline(xintercept = c(-logFCfilter,logFCfilter),lty=4,lwd=0.6,alpha=0.8)+
  theme_bw()+
  theme(panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black")) +
  theme(legend.position="top")+
  geom_point(data=subset(data, abs(logFC) >= logFCcolor & adj.P.Val <0.05),alpha=0.8, size=3,col="green4")+
  geom_text_repel(data=subset(data, abs(logFC) >= logFCcolor & adj.P.Val <0.05),
                  aes(label=gene),col="black",alpha = 0.8)

##  MAplot，更加实用！！！
## 十分重要
library(ggplot2)
library(ggrepel)
logFCfilter = 1.5
logFCcolor = 3
### 标记上下调
index = data$adj.P.Val <0.05 & abs(data$logFC) > logFCfilter
data$group <- 0
data$group[index & data$logFC>0] = 1
data$group[index & data$logFC<0] = -1
data$group <- factor(data$group,levels = c(1,0,-1),labels =c("Up","NS","Down") )
### 正式画图
ggplot(data=data, aes(x=log2(AveExpr), y =logFC,color=group)) +
  geom_point(alpha=0.8, size=1.2)+
  scale_color_manual(values = c("darkred", "grey50", "royalblue4"))+
  labs(y="log2 (Fold Change)",x="log2 (Base Mean)")+
  theme(plot.title = element_text(hjust = 0.4))+
  geom_hline(yintercept = c(logFCfilter,-logFCfilter),lty=2,lwd=1)+
  geom_hline(yintercept = 0,lwd=1.2)+
  theme_bw()+
  theme(panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black")) +
  theme(legend.position="top")+
  geom_point(data=subset(data, abs(logFC) >= logFCcolor & adj.P.Val <0.05),alpha=0.8, size=3,col="green4")+
  geom_text_repel(data=subset(data, abs(logFC) >= logFCcolor & adj.P.Val <0.05),
                  aes(label=gene),col="black",alpha = 0.8)

## 加载R包
library(export)
## 导成PPT可编辑的格式
graph2ppt(file="output/volcano.pptx")
graph2pdf(file="output/volcano.pdf")